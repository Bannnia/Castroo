function get()
    http:render("404.html", nil)
end