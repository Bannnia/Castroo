-- Valid highscores vocation id list
app.Custom.ValidHighscoreVocationList = {1, 2, 3, 4, 5, 6, 7, 8}
-- Ignore players with this group id or higher
app.Custom.HighscoreIgnoreGroup = 2