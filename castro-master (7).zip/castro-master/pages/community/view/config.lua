app.Custom.CharacterView = {
    Deaths = 5, -- Maximum number of deaths to display on character view
}