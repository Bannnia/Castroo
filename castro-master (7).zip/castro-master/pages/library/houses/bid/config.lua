--- Time to open a house bid auction when the first bid is made
app.Custom.HouseBidOpenTime = time:parseDuration("48h")