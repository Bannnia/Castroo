require "article"

function post()
	return editArticle("edit")
end