require "article"

function post()
	return editArticle("new")
end