---
Name: extension
---

# Extension metatable

Provides access to the application extension list.

- [extension:reload()](#reload)

# reload

Reloads the extension list. This process is an expensive task.

```lua
extension:reload()
```