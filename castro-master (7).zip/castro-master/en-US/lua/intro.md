---
name: Bindings
---

# Bindings

Castro exposes a good number of custom metatables to aid you at developing custom pages and widgets.