---
name: If
---

# If blocks

The syntax is the following:

```html
{{ if .var }}

{{ else }}

{{ end }}
```

You can also use:

```html
{{ if not .var }}

{{ else }}

{{ end }}
```