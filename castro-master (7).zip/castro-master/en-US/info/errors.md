---
name: Error pages
---

# Error pages

HTTP error pages are currently handled using custom lua pages.

## 404

You can process **404** pages by modifying (or creating) a custom page at `pages/404`. 
This page follows the same rules as any other custom page (all lua methods are defined here too)
