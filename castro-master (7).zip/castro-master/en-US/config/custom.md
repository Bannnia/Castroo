---
name: Custom
---

# Custom

Provides access to custom configuration values, this values are usually set during the installation process.

[You can alter this field using lua](/docs/config)