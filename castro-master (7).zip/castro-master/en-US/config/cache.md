---
name: Cache
---

# Cache

Provides access to server-side cache storage.

- [Default](#default)
- [Purge](#purge)

# Default

Default time an item is stored inside the cache.

# Purge

Time between cache purges.