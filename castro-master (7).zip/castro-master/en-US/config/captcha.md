---
name: Captcha
---

# Captcha

Provides access to google reCAPTCHA service options.

- [Enabled](#enabled)
- [Public](#public)
- [Secret](#secret)

# Enabled

Turns the captcha service on or off.

# Public

Your google reCAPTCHA public key goes here.

# Secret

Your google reCAPTCHA secret key goes here.