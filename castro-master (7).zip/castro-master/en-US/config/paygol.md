---
name: Paygol
---

# Paygol

Provides access to the website PayGol configuration values.

- [Enabled](#enabled)
- [Service](#service)
- [Secret](#secret)

# Enabled

Enables or disables the PayGol service.

# Service

Its the PayGol service identifier number.

# Secret

Your PayGol secret key. Used to verify PayGol IPN requests.