---
name: Extensions
---

# Extensions

Castro provides a very solid extension system, an easy way to separate your pages and extensions.

All extensions live on the `extensions` folder and can be of the type:

- Pages
- Widgets

## Getting extensions

You can download extensions from any source you trust, however, there is an [official extension list](https://plugins.castroaac.org) where you can upload and download extensions.