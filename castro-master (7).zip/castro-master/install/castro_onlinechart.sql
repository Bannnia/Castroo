CREATE TABLE `castro_onlinechart` (
  `count` INT(11) NOT NULL,
  `time` BIGINT(20) NOT NULL,
  PRIMARY KEY (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
