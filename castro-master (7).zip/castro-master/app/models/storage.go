package models

// Storage struct for player storage values
type Storage struct {
	Player_id int64
	Key       int
	Value     int
}
