package util

import (
	c "github.com/patrickmn/go-cache"
)

// Cache variable that holds the main cache instance of the application
var Cache *c.Cache
